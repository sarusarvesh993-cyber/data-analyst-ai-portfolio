# Data Analyst Portfolio - Sarvesh Kommawar

End-to-end analytics work covering classification, time-series forecasting, experimentation, SQL, customer segmentation, financial planning, healthcare operations, and decision-focused dashboards. Each project starts with a business question, validates its method, states its limitations, and ends with an action a stakeholder can evaluate.

> **Vercel migration:** all seven projects are implemented as a static Next.js app and validated locally with 29/29 Python tests and 10/10 browser tests. Production Vercel URL: **pending owner deployment**. See `MIGRATION_VERCEL.md`.
>
> **Legacy portfolio:** [Open the previous Streamlit app](https://data-analyst-ai-portfolio-pynrfe2h5275msvq22c7uh.streamlit.app/) during the verified cutover period.

## Projects

| # | Project | Main skills | Status |
|---|---|---|---|
| 01 | [Customer Churn & Retention](01-customer-churn/) | EDA, classification, ROC–AUC, threshold trade-offs | Analysis + app ready |
| 02 | [U.S. Retail Sales Forecast](02-sales-forecasting/) | time-series backtesting, Holt–Winters, baseline comparison | Analysis + app ready |
| 03 | [A/B Test Decision Calculator](03-ab-test/) | hypothesis testing, confidence intervals, power, practical significance | Analysis + app ready |
| 04 | [E-commerce Revenue & Cohort Analysis](04-ecommerce-sql/) | SQL, DuckDB, data modeling, cohorts, delivery KPIs | Analysis + Streamlit dashboard ready |
| 05 | [Customer Segmentation & Marketing Dashboard](05-customer-segmentation/) | RFM, K-means validation, campaign design, Power BI | Analysis + Streamlit + BI companion ready |
| 06 | [Financial Planning & Variance Command Center](06-financial-planning/) | FP&A, budget vs actual, Excel modeling, scenarios, Power BI | Analysis + Streamlit + Excel + BI companion ready |
| 07 | [India Healthcare Access & Readiness](07-healthcare-access/) | PDF extraction, DuckDB, public-health operations, readiness screening | Analysis + Streamlit + BI companion ready |

## Skills demonstrated now

`Python` · `SQL` · `DuckDB` · `pandas` · `scikit-learn` · `statsmodels` · `SciPy` · `Next.js` · `React` · `TypeScript` · `Vercel` · `Plotly` · `Streamlit` · `Excel` · `Power BI Desktop` · `DAX` · `statistics` · `cohort analysis` · `RFM segmentation` · `clustering` · `FP&A` · `scenario planning` · `data modeling` · `model validation` · `Git/GitHub`

Projects 05 and 06 include reviewed Power BI-ready tables, DAX measures, themes, and Desktop build guides. Project 06 also includes a formula-driven `.xlsx` planning model. The repository does not claim an unvalidated `.pbix` binary.

## Run the Vercel portfolio app

### Windows PowerShell

```powershell
git clone https://github.com/sarusarvesh993-cyber/data-analyst-ai-portfolio.git
cd data-analyst-ai-portfolio
npm ci
npm run dev
```

Open `http://localhost:3000`. Production static build and acceptance tests:

```powershell
npm run typecheck
npm run build
npx playwright install chromium
npm test
npm run preview
```

The production app has no Python server or required environment variables. `vercel.json` serves the generated `out/` directory as static files. See `DEPLOYMENT.md` for the connected-repository release checklist and `MIGRATION_VERCEL.md` for route/interaction parity.

### Legacy Streamlit app and original analysis

The original files remain for reproducibility and rollback reference:

```powershell
py -3.12 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements-dev.txt
pytest -q
streamlit run streamlit_app.py
```

Regenerate the reviewed Vercel data snapshots intentionally with `python scripts/export_web_data.py`; do not treat them as a live refresh service.

### Reproduce the notebooks

```powershell
pip install -r requirements-dev.txt
python .\01-customer-churn\generate_data.py
python .\03-ab-test\generate_data.py

Push-Location .\01-customer-churn
jupyter nbconvert --execute --to notebook --inplace analysis.ipynb
Pop-Location

Push-Location .\02-sales-forecasting
jupyter nbconvert --execute --to notebook --inplace analysis.ipynb
Pop-Location

Push-Location .\03-ab-test
jupyter nbconvert --execute --to notebook --inplace analysis.ipynb
Pop-Location
```

The forecasting notebook reads a committed FRED snapshot used by the app. Run `python .\02-sales-forecasting\download_data.py` when intentionally refreshing the source data.

To reproduce Projects 04–06 from their public sources:

```powershell
python .\04-ecommerce-sql\download_data.py
python .\04-ecommerce-sql\build_warehouse.py
python .\04-ecommerce-sql\run_analysis.py
python .\04-ecommerce-sql\render_assets.py

python .\05-customer-segmentation\download_data.py
python .\05-customer-segmentation\build_segments.py
python .\05-customer-segmentation\render_assets.py

python .\06-financial-planning\download_data.py
python .\06-financial-planning\build_finance.py
python .\06-financial-planning\build_excel.py
python .\06-financial-planning\render_assets.py

python .\07-healthcare-access\download_data.py
python .\07-healthcare-access\build_healthcare.py
python .\07-healthcare-access\render_assets.py
```

Raw source files and the local DuckDB database are ignored by Git; only reviewed dashboard outputs and analyst deliverables are committed for reliable deployment.

## AI-assisted insight layer

The analysis and metrics are deterministic. The Vercel edition uses authored decision briefs and deterministic rules; it makes **no live LLM call and requires no `HF_TOKEN`**. The legacy Streamlit code retains the optional controlled Hugging Face layer, where a token must remain a server-side secret.

In either delivery mode, an LLM does not generate the dataset, train the model, or calculate the statistics. This boundary keeps quantitative work distinguishable from generated prose.

## Data and limitations

- **Churn:** seeded synthetic demonstration data. It proves the workflow, not a real company's churn drivers.
- **Forecasting:** U.S. Census Bureau data via FRED, series `RSAFSNA`, not seasonally adjusted. It is a macro indicator, not store/SKU demand.
- **A/B testing:** calculator accepts real aggregate counts; the included example data are seeded and synthetic.
- **E-commerce SQL:** real anonymized Olist marketplace data from 2016–2018 under CC BY-NC-SA 4.0. Item GMV is not accounting revenue, and delivery-review relationships are descriptive rather than causal.
- **Customer segmentation:** real anonymized UCI Online Retail transactions under CC BY 4.0. Completed-purchase value is not profit, customer-level coverage excludes unidentified purchases, and segments do not establish campaign treatment effects.
- **Financial planning:** real City of Austin FY2026 budget-versus-expenditure data is used for public-finance pacing. The 75% Q3 benchmark is not an accounting forecast. A separate seeded corporate model demonstrates revenue, COGS, EBITDA, and scenarios and is always labeled synthetic.
- **Healthcare access:** official NHM quarterly MIS reports combine 2025-26 facility status with Census-2011 population and SRS health indicators. The review-priority score is a completeness-aware screening index, not a funding formula or clinical-quality ranking.

Each project README lists assumptions, methodology, source attribution, and appropriate use.

## Quality checks

```powershell
pytest -q
python -m compileall portfolio_app pages streamlit_app.py scripts/export_web_data.py
npm ci
npm run typecheck
npm run build
npm test
```

Current local evidence: **29/29 Python tests** and **10/10 production browser tests**. GitHub Actions has separate Python-analysis and Vercel-frontend jobs; hosted execution remains unclaimed until the migrated repository is pushed.

## Repository structure

```text
.
├── app/                          # eight statically exported Next.js routes
├── components/                   # interactive project tools and shared UI
├── lib/                          # statistics, formatting, CSV safety, project metadata
├── public/data/                  # reviewed browser snapshots
├── public/assets/                # actual analytical/BI images
├── public/downloads/             # Excel, DAX, theme, SQL and build-guide downloads
├── scripts/export_web_data.py    # intentional Python → JSON exporter
├── vercel.json                   # static Other preset; npm build; out directory
├── streamlit_app.py              # legacy Streamlit entry point, retained for reference
├── pages/                        # legacy Streamlit project pages
├── portfolio_app/                # reusable calculations and models
├── tests/                        # original Python and migrated Playwright checks
├── 01-customer-churn/            # notebook, data generator, findings
├── 02-sales-forecasting/         # notebook, source refresh, findings
├── 03-ab-test/                   # notebook, data generator, findings
├── 04-ecommerce-sql/             # DuckDB warehouse, SQL, outputs, source notes
├── 05-customer-segmentation/     # RFM, clustering, campaign and Power BI artifacts
├── 06-financial-planning/        # budget pacing, Excel model, scenarios and BI assets
├── 07-healthcare-access/         # NHM reports, DuckDB access mart and readiness screening
└── utils/ai_insights.py          # legacy optional text-generation layer
```

## Contact

- GitHub: [@sarusarvesh993-cyber](https://github.com/sarusarvesh993-cyber)
- LinkedIn: [Sarvesh Kommawar](https://www.linkedin.com/in/sarvesh-kommawar-3b166b278/)
- Email: kommawar57@gmail.com
